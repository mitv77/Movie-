const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'movies.json');
const PASSWORD = process.env.UPLOAD_PASSWORD || '';          // required to upload or delete
const MAX_GB = parseFloat(process.env.MAX_UPLOAD_GB || '5');  // max size per movie
const VIDEO_EXT = /\.(mp4|m4v|webm|mov|mkv|avi|ogv)$/i;

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const loadDB = () => {
  try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { return []; }
};
const saveDB = db => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
const findMovie = id => loadDB().find(m => m.id === id);
const filePathOf = m => (m ? path.join(UPLOAD_DIR, m.file) : null);

const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (req, file, cb) =>
      cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase())
  }),
  limits: { fileSize: MAX_GB * 1024 ** 3 },
  fileFilter: (req, file, cb) =>
    cb(null, VIDEO_EXT.test(file.originalname) || file.mimetype.startsWith('video/'))
});

const app = express();
app.use(express.json());

app.get('/api/config', (req, res) => {
  res.json({ passwordRequired: !!PASSWORD });
});

// List movies (name, size, date) - the stored file name stays hidden
app.get('/api/movies', (req, res) => {
  res.json(loadDB().map(({ file, ...m }) => m));
});

// Upload one movie
app.post('/api/movies', upload.single('movie'), (req, res) => {
  const file = req.file;
  const reject = (code, error) => {
    if (file) fs.unlink(file.path, () => {});
    res.status(code).json({ error });
  };
  if (PASSWORD && req.body.password !== PASSWORD) return reject(401, 'Wrong password');
  if (!file) return reject(400, 'Please choose a video file');

  const movie = {
    id: path.parse(file.filename).name,
    title: file.originalname,
    file: file.filename,
    size: file.size,
    uploaded: new Date().toISOString()
  };
  const db = loadDB();
  db.unshift(movie);
  saveDB(db);
  res.status(201).json({ id: movie.id, title: movie.title, size: movie.size, uploaded: movie.uploaded });
});

// Play: streams the file; supports seeking (HTTP Range)
app.get('/media/:id', (req, res) => {
  const m = findMovie(req.params.id);
  const p = filePathOf(m);
  if (!p || !fs.existsSync(p)) return res.status(404).send('Not found');
  res.sendFile(p);
});

// Download: saves the file with its original name
app.get('/download/:id', (req, res) => {
  const m = findMovie(req.params.id);
  const p = filePathOf(m);
  if (!p || !fs.existsSync(p)) return res.status(404).send('Not found');
  res.download(p, m.title);
});

// Delete (password protected when UPLOAD_PASSWORD is set)
app.delete('/api/movies/:id', (req, res) => {
  if (PASSWORD && req.body?.password !== PASSWORD) {
    return res.status(401).json({ error: 'Wrong password' });
  }
  const db = loadDB();
  const i = db.findIndex(m => m.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Movie not found' });
  fs.unlink(filePathOf(db[i]), () => {});
  db.splice(i, 1);
  saveDB(db);
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, 'public')));

// Errors (file too large, bad JSON, etc.) are returned as JSON
app.use((err, req, res, next) => {
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: `File is larger than ${MAX_GB} GB` });
  }
  res.status(400).json({ error: err.message });
});

const server = app.listen(PORT, () => {
  console.log(`Movie library running on port ${PORT}`);
});
server.requestTimeout = 0; // big uploads can take a long time
server.timeout = 0;
