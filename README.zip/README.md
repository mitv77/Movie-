# Movie Library

Upload movies to a server. The movie names appear on the page. Click a name to see two buttons: **Download** and **Play**.

## Files
- `server.js` - the server (saves uploads, lists movies, streams for play, sends downloads)
- `public/index.html` - the web page
- `package.json` - dependencies (Express and Multer)
- `.gitignore` - keeps movies and `node_modules` out of GitHub

## Run on your own computer first

1. Install Node.js 18 or newer from nodejs.org.
2. Open a terminal in this folder and run:
   ```bash
   npm install
   UPLOAD_PASSWORD=mysecret npm start
   ```
   On Windows PowerShell use `$env:UPLOAD_PASSWORD="mysecret"; npm start`.
3. Open `http://localhost:3000` in your browser.

Without `UPLOAD_PASSWORD`, anyone who can open the page can upload and delete. Always set a password before putting it online.

## Put the code on GitHub

```bash
git init
git add .
git commit -m "Movie library"
git branch -M main
git remote add origin https://github.com/<your-username>/movie-library.git
git push -u origin main
```

GitHub stores the code only. Movies are saved on the server's disk in the `data/` folder, which `.gitignore` keeps out of GitHub.

## Host it online

GitHub Pages cannot run this server, so the code needs a hosting service that runs Node.js. Render is one option:

1. On render.com, create a **Web Service** and connect your GitHub repository.
2. Build command: `npm install`. Start command: `npm start`.
3. Environment variables:
   - `UPLOAD_PASSWORD` = a password only you know
   - `DATA_DIR` = `/var/data`
   - `MAX_UPLOAD_GB` = `5` (optional, the default)
4. Add a **persistent disk** mounted at `/var/data`. Without it, movies are deleted every time the service restarts. Persistent disks require a paid plan.
5. Open the URL Render gives you.

## Important notes

- **Storage and bandwidth cost money.** Movies are large (1 to 4 GB each). Check your host's disk size and bandwidth limits before uploading many films.
- **Play and download links are public.** Anyone with a movie's link can watch or download it. The password only protects uploading and deleting.
- **Playable formats:** MP4 (H.264 video, AAC audio) works in every browser. WebM works in most. MKV and AVI often will not play in the browser, but Download always works.
- **Changing the file size limit:** set `MAX_UPLOAD_GB` to a bigger number.
- **Rights:** only upload films you own or have permission to share.
